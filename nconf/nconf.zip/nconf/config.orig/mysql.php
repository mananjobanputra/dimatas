<?php
##
## MYSQL config
##

#
# Main MYSQL connection parameters
#
define('DBHOST', "localhost");
define('DBNAME', "NConf");
define('DBUSER', "nconf");
define('DBPASS', "link2db");

?>
