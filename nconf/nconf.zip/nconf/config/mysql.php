<?php
##
## MYSQL config
##

#
# Main MYSQL connection parameters
#
define('DBHOST', 'localhost');
define('DBNAME', 'nconf');
define('DBUSER', 'root');
define('DBPASS', '');

?>
