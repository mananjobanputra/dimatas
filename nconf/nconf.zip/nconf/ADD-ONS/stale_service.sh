#!/bin/sh

/bin/echo "CRITICAL: Service result is stale."

exit 2
